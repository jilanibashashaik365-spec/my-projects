"""
vector_store.py — Lightweight vector store using numpy cosine similarity.
"""

import time
import random
import re
import pickle
import numpy as np
from typing import List, Dict, Tuple, Optional
from pathlib import Path

from google import genai
from google.genai import types as gtypes


EMBEDDING_MODEL = "gemini-embedding-001"
INDEX_FILE = "vectors.pkl"


def _retry(fn, *args, max_retries: int = 5, base_delay: float = 2.0, **kwargs):
    """Retry on 429 / RESOURCE_EXHAUSTED with exponential back-off + jitter."""
    for attempt in range(max_retries):
        try:
            return fn(*args, **kwargs)
        except Exception as e:
            err_str = str(e)
            is_429 = "429" in err_str or "RESOURCE_EXHAUSTED" in err_str
            if not is_429 or attempt == max_retries - 1:
                raise
            delay = base_delay * (2 ** attempt) + random.uniform(0, 1)
            match = re.search(r'retryDelay.*?(\d+)s', err_str)
            if match:
                delay = max(delay, float(match.group(1)) + random.uniform(0, 2))
            print(f"\n  ⏳ Rate limit — retrying in {delay:.1f}s "
                  f"(attempt {attempt + 1}/{max_retries})...")
            time.sleep(delay)


def get_embedding(client: genai.Client, text: str, task_type: str = "RETRIEVAL_DOCUMENT") -> List[float]:
    result = _retry(
        client.models.embed_content,
        model=EMBEDDING_MODEL,
        contents=text,
        config=gtypes.EmbedContentConfig(task_type=task_type),
    )
    return result.embeddings[0].values


class VectorStore:
    """Lightweight in-memory vector store using numpy cosine similarity."""

    def __init__(self, client: genai.Client, index_dir: str = ".index"):
        self.client = client
        self.index_dir = Path(index_dir)
        self.index_dir.mkdir(parents=True, exist_ok=True)
        self.embeddings: List[np.ndarray] = []
        self.chunks: List[Dict] = []
        # Cached pre-normalised (N, D) matrix for fast vectorised search.
        self._emb_matrix: Optional[np.ndarray] = None

    def build(self, chunks: List[Dict]) -> None:
        print("  Generating embeddings with Gemini...")
        self.embeddings = []
        self.chunks = []
        self._emb_matrix = None
        total = len(chunks)
        for i, chunk in enumerate(chunks):
            print(f"  Embedding {i+1}/{total}...", end="\r")
            emb = get_embedding(self.client, chunk["text"], task_type="RETRIEVAL_DOCUMENT")
            self.embeddings.append(np.array(emb, dtype=np.float32))
            self.chunks.append(chunk)
        print(f"\n  Done! {len(self.embeddings)} embeddings generated.")
        self._save()

    def _save(self) -> None:
        data = {"embeddings": self.embeddings, "chunks": self.chunks}
        with open(self.index_dir / INDEX_FILE, "wb") as f:
            pickle.dump(data, f)
        print(f"  Index saved to: {self.index_dir}/")

    def load(self) -> bool:
        path = self.index_dir / INDEX_FILE
        if not path.exists():
            return False
        with open(path, "rb") as f:
            data = pickle.load(f)
        self.embeddings = data["embeddings"]
        self.chunks = data["chunks"]
        self._emb_matrix = None
        print(f"  Loaded existing index: {len(self.chunks)} chunks")
        return True

    def _get_emb_matrix(self) -> np.ndarray:
        """Lazily build a row-normalised (N, D) matrix for fast batch search."""
        if self._emb_matrix is None:
            matrix = np.stack(self.embeddings)
            norms = np.linalg.norm(matrix, axis=1, keepdims=True)
            self._emb_matrix = matrix / (norms + 1e-10)
        return self._emb_matrix

    def search(self, query: str, top_k: int = 4) -> List[Tuple[Dict, float]]:
        if not self.embeddings:
            return []

        query_emb = np.array(
            get_embedding(self.client, query, task_type="RETRIEVAL_QUERY"),
            dtype=np.float32,
        )

        emb_matrix = self._get_emb_matrix()
        query_norm = np.linalg.norm(query_emb)
        query_normed = query_emb / (query_norm + 1e-10)
        scores = emb_matrix @ query_normed

        k = min(top_k, len(scores))
        top_idx = np.argpartition(scores, -k)[-k:]
        top_idx = top_idx[np.argsort(scores[top_idx])[::-1]]

        return [(self.chunks[int(i)], float(scores[i])) for i in top_idx]
