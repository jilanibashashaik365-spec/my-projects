"""
document_loader.py — Loads .txt, .pdf, and .docx files from a directory.
Supports chunking with overlap for better retrieval quality.
"""

import os
import re
from pathlib import Path
from typing import List, Dict


def load_txt(filepath: str) -> str:
    """Load plain text file."""
    with open(filepath, "r", encoding="utf-8", errors="ignore") as f:
        return f.read()


def load_pdf(filepath: str) -> str:
    """Load PDF file using PyPDF2."""
    try:
        import PyPDF2
        text = []
        with open(filepath, "rb") as f:
            reader = PyPDF2.PdfReader(f)
            for page in reader.pages:
                page_text = page.extract_text()
                if page_text:
                    text.append(page_text)
        return "\n".join(text)
    except ImportError:
        print("  [!] PyPDF2 not installed. Skipping PDF file.")
        return ""
    except Exception as e:
        print(f"  [!] Error reading PDF {filepath}: {e}")
        return ""


def load_docx(filepath: str) -> str:
    """Load Word .docx file using python-docx."""
    try:
        from docx import Document
        doc = Document(filepath)
        paragraphs = [para.text for para in doc.paragraphs if para.text.strip()]
        return "\n".join(paragraphs)
    except ImportError:
        print("  [!] python-docx not installed. Skipping DOCX file.")
        return ""
    except Exception as e:
        print(f"  [!] Error reading DOCX {filepath}: {e}")
        return ""


def chunk_text(text: str, chunk_size: int = 500, overlap: int = 100) -> List[str]:
    """
    Split text into overlapping chunks.

    Args:
        text: Raw text to split.
        chunk_size: Approximate number of characters per chunk.
        overlap: Number of characters to overlap between chunks.
                 Capped internally to chunk_size // 4 to guarantee progress.

    Returns:
        List of text chunks.
    """
    if chunk_size <= 0:
        raise ValueError(f"chunk_size must be positive, got {chunk_size}")

    # Cap overlap to 25% of chunk_size to guarantee forward progress on every iteration.
    overlap = min(overlap, chunk_size // 4)

    # Normalize whitespace
    text = re.sub(r'\n{3,}', '\n\n', text.strip())

    chunks = []
    start = 0
    text_len = len(text)

    # Search for a natural boundary (sentence end or newline) only in the
    # second half of each window so the cursor always advances meaningfully.
    search_offset = chunk_size // 2

    while start < text_len:
        end = min(start + chunk_size, text_len)

        if end < text_len:
            search_start = start + search_offset
            boundary = max(
                text.rfind('. ', search_start, end),
                text.rfind('\n',  search_start, end),
            )
            if boundary > search_start:
                end = boundary + 1

        chunk = text[start:end].strip()
        if chunk:
            chunks.append(chunk)

        # Stop once we've consumed the full document.
        if end >= text_len:
            break
        start = end - overlap

    return chunks


def load_documents(docs_dir: str, chunk_size: int = 500, overlap: int = 100) -> List[Dict]:
    """
    Load all supported documents from a directory and chunk them.

    Args:
        docs_dir: Path to directory containing documents.
        chunk_size: Characters per chunk.
        overlap: Overlap between consecutive chunks.

    Returns:
        List of dicts with keys: 'text', 'source', 'chunk_id'.
    """
    supported = {".txt": load_txt, ".pdf": load_pdf, ".docx": load_docx}
    docs_path = Path(docs_dir)
    all_chunks = []
    file_count = 0

    if not docs_path.exists():
        print(f"[!] Documents directory not found: {docs_dir}")
        return []

    for filepath in sorted(docs_path.iterdir()):
        ext = filepath.suffix.lower()
        if ext not in supported:
            continue

        print(f"  📄 Loading: {filepath.name}")
        raw_text = supported[ext](str(filepath))

        if not raw_text.strip():
            print(f"     [!] Empty or unreadable: {filepath.name}")
            continue

        chunks = chunk_text(raw_text, chunk_size=chunk_size, overlap=overlap)
        for i, chunk in enumerate(chunks):
            all_chunks.append({
                "text": chunk,
                "source": filepath.name,
                "chunk_id": f"{filepath.stem}_chunk_{i}",
            })

        print(f"     ✅ {len(chunks)} chunks created")
        file_count += 1

    print(f"\n  📚 Total: {file_count} files → {len(all_chunks)} chunks\n")
    return all_chunks
