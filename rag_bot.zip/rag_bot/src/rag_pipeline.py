"""
rag_pipeline.py — Orchestrates the full RAG pipeline using google-genai SDK.
"""

import time
import random
import re
from typing import List, Dict, Tuple
from pathlib import Path

from google import genai
from google.genai import types as gtypes

from src.document_loader import load_documents
from src.vector_store import VectorStore


# gemini-2.0-flash retired March 2026 — free tier quota is now 0.
# gemini-2.5-flash-lite: 15 RPM / 1,000 RPD on free tier (best quota)
# gemini-2.5-flash:      10 RPM /   250 RPD on free tier (better quality)
GENERATION_MODEL = "gemini-2.5-flash-lite"

SYSTEM_PROMPT = (
    "You are a helpful Document Q&A Assistant. "
    "Answer the user's question using ONLY the context provided below. "
    "If the answer cannot be found in the context, say: "
    "'I don't have enough information in the provided documents to answer this question.' "
    "Be concise, accurate, and cite the source document name when relevant. "
    "Do NOT make up information beyond what is given in the context."
)


def _retry(fn, *args, max_retries: int = 5, base_delay: float = 2.0, **kwargs):
    """
    Call fn(*args, **kwargs); retry on 429 / RESOURCE_EXHAUSTED with
    exponential back-off + jitter.  Respects the retryDelay hint in the
    error body when present.
    """
    for attempt in range(max_retries):
        try:
            return fn(*args, **kwargs)
        except Exception as e:
            err_str = str(e)
            is_429 = "429" in err_str or "RESOURCE_EXHAUSTED" in err_str
            if not is_429 or attempt == max_retries - 1:
                raise
            # Use Google's suggested delay if available, otherwise back-off
            delay = base_delay * (2 ** attempt) + random.uniform(0, 1)
            match = re.search(r'retryDelay.*?(\d+)s', err_str)
            if match:
                delay = max(delay, float(match.group(1)) + random.uniform(0, 2))
            print(f"\n  ⏳ Rate limit — retrying in {delay:.1f}s "
                  f"(attempt {attempt + 1}/{max_retries})...")
            time.sleep(delay)


def build_prompt(query: str, context_chunks: List[Tuple[Dict, float]]) -> str:
    parts = []
    for chunk, score in context_chunks:
        parts.append(f"[Source: {chunk['source']} | Relevance: {score:.2f}]\n{chunk['text']}")
    context_str = "\n\n---\n\n".join(parts)
    return (
        f"CONTEXT:\n{context_str}\n\n"
        f"USER QUESTION: {query}\n\n"
        f"ANSWER:"
    )


class RAGPipeline:
    """End-to-end Retrieval-Augmented Generation pipeline."""

    def __init__(
        self,
        api_key: str,
        docs_dir: str = "documents",
        index_dir: str = ".index",
        chunk_size: int = 500,
        overlap: int = 100,
        top_k: int = 4,
        force_rebuild: bool = False,
    ):
        self.client = genai.Client(api_key=api_key)
        self.docs_dir = docs_dir
        self.chunk_size = chunk_size
        self.overlap = overlap
        self.top_k = top_k
        self.store = VectorStore(client=self.client, index_dir=index_dir)
        self._setup_index(force_rebuild)

    def _setup_index(self, force_rebuild: bool) -> None:
        if not force_rebuild and self.store.load():
            print("  ♻️  Using cached index (use --rebuild to refresh)")
            return
        print("  📂 Loading documents...")
        chunks = load_documents(self.docs_dir, self.chunk_size, self.overlap)
        if not chunks:
            raise ValueError(
                f"No documents found in '{self.docs_dir}'. "
                "Add .txt, .pdf, or .docx files."
            )
        self.store.build(chunks)

    def query(self, question: str) -> Dict:
        results = self.store.search(question, top_k=self.top_k)
        if not results:
            return {
                "answer": "No relevant documents found.",
                "sources": [],
                "context_chunks": [],
            }
        prompt = build_prompt(question, results)

        response = _retry(
            self.client.models.generate_content,
            model=GENERATION_MODEL,
            contents=prompt,
            config=gtypes.GenerateContentConfig(
                system_instruction=SYSTEM_PROMPT,
                max_output_tokens=1024,
                temperature=0.2,
            ),
        )

        answer = response.text.strip()
        sources = list(dict.fromkeys(c["source"] for c, _ in results))
        return {
            "answer": answer,
            "sources": sources,
            "context_chunks": [(c["text"], s) for c, s in results],
        }
