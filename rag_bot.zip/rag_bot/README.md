# 📚 Document Q&A Bot — RAG Pipeline

A **Retrieval-Augmented Generation (RAG)** chatbot that answers questions from your own documents using **Google Gemini** (free via Google AI Studio) and **NumPy cosine similarity** for vector search.

---

## 🏗️ Architecture

```
User Question
     │
     ▼
[Query Embedding]  ──►  Google Gemini gemini-embedding-001
     │
     ▼
[Vector Search]    ──►  NumPy in-memory index (cosine similarity)
     │
     ▼
[Top-K Chunks Retrieved]
     │
     ▼
[Prompt Construction]  ──►  System Prompt + Context + Question
     │
     ▼
[Answer Generation]  ──►  Google Gemini 2.5 Flash Lite
     │
     ▼
   Answer + Sources
```

### How RAG Works (Step-by-Step)

| Step | What Happens |
|------|-------------|
| 1. Ingest | Documents (`.txt`, `.pdf`, `.docx`) are loaded from the `documents/` folder |
| 2. Chunk | Each document is split into overlapping chunks (~500 chars) |
| 3. Embed | Each chunk is converted to a 768-dim vector via Gemini `gemini-embedding-001` |
| 4. Index | Vectors are stored as a row-normalised NumPy matrix (pickle-cached to disk) |
| 5. Query | User question is embedded with the same model (task_type=RETRIEVAL_QUERY) |
| 6. Retrieve | Top-K most similar chunks are found via matrix dot-product (cosine similarity) |
| 7. Generate | Chunks + question are sent to **Gemini 2.5 Flash Lite** for a grounded answer |

---

## 🛠️ Tech Stack

| Component | Tool |
|-----------|------|
| Language | Python 3.11+ |
| LLM | Google Gemini 2.5 Flash Lite (free via AI Studio) |
| Embeddings | Google Gemini `gemini-embedding-001` |
| Vector Store | NumPy (in-memory, pickle-cached) |
| PDF Support | PyPDF2 |
| DOCX Support | python-docx |
| CLI UX | Colorama |
| Config | python-dotenv |

> **Note:** The vector store uses NumPy cosine similarity — no external vector DB required.

---

## 📁 Project Structure

```
rag_bot/
├── main.py                   # Entry point — interactive chatbot
├── requirements.txt          # Python dependencies
├── .env.example              # API key template
├── .gitignore
│
├── documents/                # 📄 Put your documents here
│   ├── company_policy.txt
│   ├── python_guide.txt
│   └── ai_ml_overview.txt
│
├── src/                      # Core pipeline modules
│   ├── __init__.py
│   ├── document_loader.py    # Loads & chunks .txt/.pdf/.docx files
│   ├── vector_store.py       # NumPy vector store: build, save, load, search
│   └── rag_pipeline.py       # Orchestrates retrieval + generation
│
└── scripts/
    ├── ingest_docs.py         # Standalone indexing script
    └── evaluate.py            # Batch evaluation on test questions
```

---

## ⚡ Quick Start

### 1. Clone / Download the Project

```bash
git clone https://github.com/<your-username>/rag-document-qna-bot.git
cd rag-document-qna-bot
```

### 2. Create a Virtual Environment

```bash
python -m venv venv

# Windows
venv\Scripts\activate

# macOS/Linux
source venv/bin/activate
```

### 3. Install Dependencies

```bash
pip install -r requirements.txt
```

### 4. Get a Free Google AI Studio API Key

1. Go to: **https://aistudio.google.com/app/apikey**
2. Sign in with your Google account
3. Click **"Create API Key"**
4. Copy the key

### 5. Configure the API Key

```bash
cp .env.example .env
```

Open `.env` and replace `your_api_key_here` with your actual key:

```
GOOGLE_API_KEY=AIzaSy...your_actual_key...
```

### 6. Add Your Documents

Place `.txt`, `.pdf`, or `.docx` files inside the `documents/` folder.  
Sample documents are already included to get you started.

### 7. Run the Chatbot

```bash
python main.py
```

The first run builds and caches the vector index (takes ~30 seconds for sample docs). Subsequent runs load the cached index instantly.

---

## 💬 Chat Commands

| Command | Action |
|---------|--------|
| Type any question | Get an AI-powered answer |
| `sources` | Show document sources from last answer |
| `context` | Show raw retrieved chunks |
| `rebuild` | Re-index documents (after adding new files) |
| `help` | Show command list |
| `quit` / `exit` | Exit the chatbot |

---

## 🚀 CLI Options

```bash
# Force rebuild index (useful after adding new documents)
python main.py --rebuild

# Use a custom documents folder
python main.py --docs-dir /path/to/my_docs

# Run demo questions without entering chat
python main.py --demo

# Tune retrieval: retrieve top-6 chunks instead of 4
python main.py --top-k 6

# Adjust chunk size and overlap
python main.py --chunk-size 600 --overlap 150
```

---

## 🧪 Evaluation

Run automated evaluation on 8 sample questions:

```bash
python scripts/evaluate.py
```

Results are saved to `evaluation_results.json`.

---

## 📊 Sample Q&A

**Q: How many days of annual leave are employees entitled to?**  
> Employees are entitled to 18 days of paid annual leave per year.  
> 📖 Source: company_policy.txt

**Q: Explain Retrieval-Augmented Generation.**  
> RAG is an AI framework that combines information retrieval with text generation. Documents are split into chunks, converted to embeddings, and stored in a vector database. When a user queries, similar chunks are retrieved and passed to an LLM for grounded answer generation.  
> 📖 Source: ai_ml_overview.txt

**Q: What Python libraries are used for machine learning?**  
> Scikit-learn is used for machine learning in Python. For deep learning, other libraries are common. For data analysis, NumPy and Pandas are the standard choices.  
> 📖 Source: python_guide.txt

---

## 🌐 Supported Document Formats

| Format | Extension | Library |
|--------|-----------|---------| 
| Plain Text | `.txt` | Built-in |
| PDF | `.pdf` | PyPDF2 |
| Word Document | `.docx` | python-docx |

---

## 🔧 Customization

### Change the LLM Model
In `src/rag_pipeline.py`:
```python
GENERATION_MODEL = "gemini-2.5-flash-lite"  # or "gemini-2.5-flash" for higher quality
```

### Change Chunk Size
Smaller chunks → more precise retrieval  
Larger chunks → more context per chunk
```bash
python main.py --chunk-size 300 --overlap 50
```

### Change Number of Retrieved Chunks
```bash
python main.py --top-k 6
```

---

## ⚠️ Notes & Limitations

- **Free API limits**: Google AI Studio free tier allows ~15 RPM for Gemini 2.5 Flash Lite. The pipeline includes automatic exponential back-off and retry on rate-limit (429) errors.
- **Context window**: Answers are only as good as the retrieved chunks. If information spans multiple sections, consider increasing `--top-k`.
- **No chat history**: This is a single-turn Q&A bot. Each question is independent.
- **Hallucinations**: The system prompt instructs Gemini to answer only from context, minimizing but not eliminating hallucinations.
- **Index persistence**: The vector index is saved as `.index/vectors.pkl`. Delete this folder or run `--rebuild` after adding or removing documents.

---

## 📄 License

MIT License — Free for personal and commercial use.

---

*Built with ❤️ using Google Gemini + NumPy*
