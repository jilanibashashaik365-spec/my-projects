#!/usr/bin/env python3
"""
main.py — Entry point for the Document Q&A Bot (RAG Pipeline)
Usage:
    python main.py                        # interactive chat
    python main.py --rebuild              # force rebuild vector index
    python main.py --docs-dir my_docs     # custom documents folder
    python main.py --demo                 # run demo questions and exit
"""

import os, sys, argparse
from pathlib import Path

from colorama import init, Fore, Style
from dotenv import load_dotenv

init(autoreset=True)

BANNER = f"""
{Fore.CYAN}╔══════════════════════════════════════════════════════╗
║       📚  Document Q&A Bot  — RAG Pipeline           ║
║       Powered by Google Gemini + NumPy               ║
╚══════════════════════════════════════════════════════╝{Style.RESET_ALL}
"""

HELP_TEXT = f"""
{Fore.YELLOW}Commands:{Style.RESET_ALL}
  Type your question and press Enter
  {Fore.GREEN}sources{Style.RESET_ALL}     — show sources used in last answer
  {Fore.GREEN}context{Style.RESET_ALL}     — show raw retrieved chunks from last query
  {Fore.GREEN}rebuild{Style.RESET_ALL}     — reload and re-index all documents
  {Fore.GREEN}help{Style.RESET_ALL}        — show this help
  {Fore.GREEN}quit / exit{Style.RESET_ALL} — exit the chatbot
"""

DEMO_QUESTIONS = [
    "How many days of annual leave are employees entitled to?",
    "Explain Retrieval-Augmented Generation and how it works.",
    "What Python libraries are used for data analysis and machine learning?",
]


def get_api_key() -> str:
    load_dotenv()
    key = os.getenv("GOOGLE_API_KEY", "").strip()
    if key:
        return key
    print(f"{Fore.YELLOW}⚠️  GOOGLE_API_KEY not found in environment or .env file.{Style.RESET_ALL}")
    print(f"   Get a free key at: {Fore.CYAN}https://aistudio.google.com/app/apikey{Style.RESET_ALL}\n")
    key = input("Paste your Google AI Studio API key: ").strip()
    if not key:
        print(f"{Fore.RED}✗ No API key provided. Exiting.{Style.RESET_ALL}")
        sys.exit(1)
    save = input("Save key to .env for future use? [y/N] ").strip().lower()
    if save == "y":
        with open(".env", "a") as f:
            f.write(f"\nGOOGLE_API_KEY={key}\n")
        print(f"{Fore.GREEN}✓ Key saved to .env{Style.RESET_ALL}")
    return key


def print_answer(result: dict) -> None:
    print(f"\n{Fore.GREEN}🤖 Answer:{Style.RESET_ALL}")
    print(result["answer"])
    src_str = ", ".join(result["sources"]) if result["sources"] else "N/A"
    print(f"\n{Fore.CYAN}📖 Sources: {src_str}{Style.RESET_ALL}\n")


def run_interactive(pipeline) -> None:
    print(HELP_TEXT)
    last_result = None
    while True:
        try:
            user_input = input(f"{Fore.YELLOW}You: {Style.RESET_ALL}").strip()
        except (KeyboardInterrupt, EOFError):
            print(f"\n{Fore.CYAN}Goodbye! 👋{Style.RESET_ALL}")
            break

        if not user_input:
            continue
        cmd = user_input.lower()

        if cmd in ("quit", "exit", "q"):
            print(f"{Fore.CYAN}Goodbye! 👋{Style.RESET_ALL}")
            break
        elif cmd == "help":
            print(HELP_TEXT)
        elif cmd == "sources":
            if last_result:
                print(f"{Fore.CYAN}Sources: {', '.join(last_result['sources'])}{Style.RESET_ALL}")
            else:
                print("No previous query yet.")
        elif cmd == "context":
            if last_result:
                for i, (text, score) in enumerate(last_result["context_chunks"], 1):
                    print(f"\n{Fore.CYAN}--- Chunk {i} (score: {score:.3f}) ---{Style.RESET_ALL}")
                    print(text[:400] + ("..." if len(text) > 400 else ""))
            else:
                print("No previous query yet.")
        elif cmd == "rebuild":
            print(f"{Fore.YELLOW}Rebuilding index...{Style.RESET_ALL}")
            from src.document_loader import load_documents
            chunks = load_documents(pipeline.docs_dir, pipeline.chunk_size, pipeline.overlap)
            pipeline.store.build(chunks)
            print(f"{Fore.GREEN}✓ Index rebuilt!{Style.RESET_ALL}")
        else:
            print(f"{Fore.BLUE}⏳ Thinking...{Style.RESET_ALL}")
            try:
                last_result = pipeline.query(user_input)
                print_answer(last_result)
            except Exception as e:
                print(f"{Fore.RED}Error: {e}{Style.RESET_ALL}")


def run_demo(pipeline) -> None:
    print(f"\n{Fore.CYAN}=== DEMO MODE: {len(DEMO_QUESTIONS)} sample questions ==={Style.RESET_ALL}\n")
    for i, q in enumerate(DEMO_QUESTIONS, 1):
        print(f"{Fore.YELLOW}Q{i}: {q}{Style.RESET_ALL}")
        print(f"{Fore.BLUE}⏳ Thinking...{Style.RESET_ALL}")
        result = pipeline.query(q)
        print_answer(result)
        print("─" * 60)


def main():
    parser = argparse.ArgumentParser(description="Document Q&A Bot (RAG Pipeline)")
    parser.add_argument("--rebuild", action="store_true", help="Force rebuild vector index")
    parser.add_argument("--docs-dir", default="documents")
    parser.add_argument("--index-dir", default=".index")
    parser.add_argument("--top-k", type=int, default=4)
    parser.add_argument("--chunk-size", type=int, default=500)
    parser.add_argument("--overlap", type=int, default=100)
    parser.add_argument("--demo", action="store_true", help="Run demo questions and exit")
    args = parser.parse_args()

    print(BANNER)

    docs_path = Path(args.docs_dir)
    if not docs_path.exists():
        print(f"{Fore.RED}✗ Documents directory not found: '{args.docs_dir}'{Style.RESET_ALL}")
        sys.exit(1)

    api_key = get_api_key()

    print(f"\n{Fore.CYAN}🚀 Initializing RAG Pipeline...{Style.RESET_ALL}")
    try:
        from src.rag_pipeline import RAGPipeline
        pipeline = RAGPipeline(
            api_key=api_key,
            docs_dir=args.docs_dir,
            index_dir=args.index_dir,
            chunk_size=args.chunk_size,
            overlap=args.overlap,
            top_k=args.top_k,
            force_rebuild=args.rebuild,
        )
        print(f"{Fore.GREEN}✓ Pipeline ready!{Style.RESET_ALL}")
    except Exception as e:
        print(f"{Fore.RED}✗ Failed to initialize pipeline: {e}{Style.RESET_ALL}")
        sys.exit(1)

    if args.demo:
        run_demo(pipeline)
    else:
        run_interactive(pipeline)


if __name__ == "__main__":
    main()
