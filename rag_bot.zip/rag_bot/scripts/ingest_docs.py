#!/usr/bin/env python3
"""
scripts/ingest_docs.py — Standalone script to load, chunk, and index documents.

Usage:
    python scripts/ingest_docs.py
    python scripts/ingest_docs.py --docs-dir my_folder --chunk-size 600
"""

import os, sys, argparse
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent))

from colorama import init, Fore, Style
from dotenv import load_dotenv
from google import genai

from src.document_loader import load_documents
from src.vector_store import VectorStore

init(autoreset=True)

def main():
    parser = argparse.ArgumentParser(description="Ingest and index documents")
    parser.add_argument("--docs-dir", default="documents")
    parser.add_argument("--index-dir", default=".index")
    parser.add_argument("--chunk-size", type=int, default=500)
    parser.add_argument("--overlap", type=int, default=100)
    args = parser.parse_args()

    load_dotenv()
    api_key = os.getenv("GOOGLE_API_KEY", "").strip()
    if not api_key:
        api_key = input("Enter your Google AI Studio API key: ").strip()
    if not api_key:
        print(f"{Fore.RED}No API key. Exiting.{Style.RESET_ALL}")
        sys.exit(1)

    client = genai.Client(api_key=api_key)
    docs_path = Path(args.docs_dir)
    if not docs_path.exists():
        print(f"{Fore.RED}✗ Directory not found: {args.docs_dir}{Style.RESET_ALL}")
        sys.exit(1)

    print(f"\n{Fore.CYAN}📂 Loading documents from: {args.docs_dir}{Style.RESET_ALL}")
    chunks = load_documents(args.docs_dir, args.chunk_size, args.overlap)
    if not chunks:
        print(f"{Fore.RED}✗ No documents found.{Style.RESET_ALL}")
        sys.exit(1)

    print(f"{Fore.CYAN}🔢 Building vector index...{Style.RESET_ALL}")
    store = VectorStore(client=client, index_dir=args.index_dir)
    store.build(chunks)
    print(f"\n{Fore.GREEN}✅ Done! {len(chunks)} chunks indexed.{Style.RESET_ALL}")

if __name__ == "__main__":
    main()
