#!/usr/bin/env python3
"""
scripts/evaluate.py — Batch evaluation on test questions.

Usage:
    python scripts/evaluate.py
"""

import os, sys, json
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent))

from colorama import init, Fore, Style
from dotenv import load_dotenv

init(autoreset=True)

TEST_QUESTIONS = [
    "How many days of annual leave are employees entitled to?",
    "What is the WFH policy?",
    "Explain Retrieval-Augmented Generation.",
    "What are the different types of machine learning?",
    "What Python libraries are used for machine learning?",
    "What happens after two consecutive bad performance reviews?",
    "Who created Python and when was it released?",
    "What is the company's data security policy?",
]

def main():
    load_dotenv()
    api_key = os.getenv("GOOGLE_API_KEY", "").strip()
    if not api_key:
        api_key = input("Enter Google AI Studio API key: ").strip()
    if not api_key:
        print(f"{Fore.RED}No API key. Exiting.{Style.RESET_ALL}")
        sys.exit(1)

    from src.rag_pipeline import RAGPipeline
    print(f"\n{Fore.CYAN}🚀 Initializing RAG Pipeline for evaluation...{Style.RESET_ALL}\n")
    pipeline = RAGPipeline(api_key=api_key)

    results = []
    for i, question in enumerate(TEST_QUESTIONS, 1):
        print(f"{Fore.YELLOW}[{i}/{len(TEST_QUESTIONS)}] Q: {question}{Style.RESET_ALL}")
        result = pipeline.query(question)
        print(f"{Fore.GREEN}A: {result['answer']}{Style.RESET_ALL}")
        print(f"{Fore.CYAN}   Sources: {', '.join(result['sources'])}{Style.RESET_ALL}\n")
        results.append({
            "question": question,
            "answer": result["answer"],
            "sources": result["sources"],
        })

    output_path = Path("evaluation_results.json")
    with open(output_path, "w") as f:
        json.dump(results, f, indent=2)
    print(f"\n{Fore.GREEN}✅ Results saved to: {output_path}{Style.RESET_ALL}")

if __name__ == "__main__":
    main()
